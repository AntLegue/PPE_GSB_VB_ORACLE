﻿Public Class accueil

    Public idvisiteur As Integer = saisie_login.idvisiteur

    Private Sub saisie_cr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles saisir_cr.Click
        Me.Hide()
        select_prat.Show()
    End Sub

    Private Sub consult_cr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles consult_cr.Click
        Me.Hide()
        select_rapport.Show()
    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click
        Me.Hide()
        saisie_login.Show()
    End Sub

    Private Sub accueil_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class