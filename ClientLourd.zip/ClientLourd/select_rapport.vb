﻿Public Class select_rapport

    Dim idvisiteur As Integer = accueil.idvisiteur
    Public idrapport As Integer
    Dim myCommand As New Odbc.OdbcCommand
    Dim myReader As Odbc.OdbcDataReader
    Dim myAdapter As Odbc.OdbcDataAdapter
    Dim myBuilder As Odbc.OdbcCommandBuilder
    Dim donnee As DataTable

    Private Sub selectrapport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        Dim query As String = "SELECT id, (to_char(date_visite, 'DD/MM/YY') || '-' ||nom_praticien || ' ' || prenom_praticien) date_praticien FROM rapport, praticien WHERE id_visiteur = " & idvisiteur & " AND praticien.num_rpps = id_praticien ORDER BY date_visite DESC"

        donnee = New DataTable
        myAdapter = New Odbc.OdbcDataAdapter(query, saisie_login.myConnection)
        myBuilder = New Odbc.OdbcCommandBuilder(myAdapter)
        myAdapter.Fill(donnee)

        Me.listerapport.DataSource = donnee
        Me.listerapport.DisplayMember = "date_praticien"
        Me.listerapport.ValueMember = "id"

    End Sub

    Private Sub listerapport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles listerapport.Click

        saisie_login.myConnection.Close()
        saisie_login.myConnection.Open()

        Dim idchoix As String = listerapport.SelectedValue
        idrapport = idchoix


        consult_rapport.Show()

    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click
        Me.Close()
    End Sub

    Private Sub saisir_cr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles saisir_cr.Click
        Me.Hide()
        accueil.Show()
    End Sub

    Private Sub listerapport_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles listerapport.SelectedIndexChanged
        Me.Hide()
    End Sub
End Class