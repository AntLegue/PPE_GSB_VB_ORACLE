﻿Public Class consult_rapport
    Dim idrapport As Integer = select_rapport.idrapport

    Dim myCommand As New Odbc.OdbcCommand
    Dim myReader As Odbc.OdbcDataReader
    Dim myAdapter As Odbc.OdbcDataAdapter
    Dim myBuilder As Odbc.OdbcCommandBuilder
    Dim donnee As DataTable


    Private Sub consulterrapport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim query As String = "SELECT date_visite, rapport_visite FROM rapport WHERE id = " & idrapport

        myCommand.Connection = saisie_login.myConnection
        myCommand.CommandText = query
        myReader = myCommand.ExecuteReader

        Dim daterapport As Date
        Dim contenurapport As String = ""

        While myReader.Read
            daterapport = myReader.GetValue(0)
            contenurapport = myReader.GetValue(1)
        End While

        labelrapport.Text = "Rapport datant du : " & daterapport
        rapport.Text = contenurapport

        saisie_login.myConnection.Close()
        saisie_login.myConnection.Open()


        Dim query2 As String = " Select libelle_medicament, quantite FROM medicament, quantite WHERE medicament.code_medicament = quantite.code_medicament AND id_rapport = " & idrapport

        myCommand.Connection = saisie_login.myConnection
        myCommand.CommandText = query2
        myReader = myCommand.ExecuteReader

        While myReader.Read

            listemedicaments.Items.Add(myReader.GetValue(0))
            listequantite.Items.Add(myReader.GetValue(1))
        End While


    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click
        Application.Exit()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Hide()
        select_rapport.Show()
    End Sub

    Private Sub saisir_cr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles saisir_cr.Click
        Me.Hide()
        accueil.Show()
    End Sub

End Class