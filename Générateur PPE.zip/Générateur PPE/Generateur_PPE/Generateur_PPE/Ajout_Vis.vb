﻿Public Class Ajout_Vis

    Dim myCommand As New Odbc.OdbcCommand
    Dim myReader As Odbc.OdbcDataReader
    Dim myAdapter As Odbc.OdbcDataAdapter
    Dim myBuilder As Odbc.OdbcCommandBuilder
    Dim donnee As DataTable

    Private Sub Ajout_Vis_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim query As String = "SELECT table_name FROM user_tables"
        myCommand.Connection = Accueil_Gen.myConnection
        myCommand.CommandText = query
        myReader = myCommand.ExecuteReader


        While myReader.Read
            Scrollbar.Items.Add(myReader.GetString(0))
        End While
        myReader.Close()

    End Sub
    Private Sub Scrollbar_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Scrollbar.SelectedIndexChanged

        Dim table_name As String = Scrollbar.SelectedItem.ToString()
        Dim query As String = "SELECT * FROM " & table_name
        donnee = New DataTable
        myAdapter = New Odbc.OdbcDataAdapter(query, Accueil_Gen.myConnection)
        myBuilder = New Odbc.OdbcCommandBuilder(myAdapter)
        myAdapter.Fill(donnee)
        AfficheTab.DataSource = donnee

    End Sub

    Private Sub AjoutVis_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AjoutVis.Click

        ' déclaration des variables
        Dim nom_vis As String
        Dim prenom_vis As String
        Dim adresse_vis As String
        Dim mdp_vis As String
        Dim MyCommand As New Odbc.OdbcCommand

        ' intégration des textbox
        nom_vis = Insert_Nom.Text
        prenom_vis = Insert_Prenom.Text
        adresse_vis = Insert_MDP.Text
        mdp_vis = Insert_MDP.Text

        'requete
        MyCommand.CommandText = "INSERT INTO VISITEUR (ID, PRENOM_VISITEUR, NOM_VISITEUR, MDP) VALUES(SeqVisiteur.NEXTVAL, '" & prenom_vis & "' , '" & nom_vis & "', '" & mdp_vis & "') "

        'envoie de la requête
        MyCommand.Connection = Accueil_Gen.myConnection
        MyCommand.ExecuteNonQuery()

        ' Supprimer la zone de texte s
        Insert_Nom.Clear()
        Insert_Prenom.Clear()
        Insert_Adresse.Clear()
        Insert_MDP.Clear()

    End Sub

    Private Sub RetourAccueil_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RetourAccueil.Click

        ' on affiche l'accueil du form accueil
        Accueil_Gen.Show()
        ' on cache le form actuel
        Me.Hide()

    End Sub
End Class