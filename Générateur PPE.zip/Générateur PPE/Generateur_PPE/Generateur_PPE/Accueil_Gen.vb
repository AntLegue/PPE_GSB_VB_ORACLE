﻿
Public Class Accueil_Gen

    Public myConnection As New Odbc.OdbcConnection
    Dim myCommand As New Odbc.OdbcCommand
    Dim myReader As Odbc.OdbcDataReader
    Dim myAdapter As Odbc.OdbcDataAdapter
    Dim myBuilder As Odbc.OdbcCommandBuilder
    Dim connString As String
    Dim donnee As DataTable

    ' Section visiteurs
    Private Sub AddVis_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddVis.Click

        Ajout_Vis.Show()
        Me.Hide()

    End Sub

    ' Section Medicament
    Private Sub AddMedic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddMedic.Click

        Ajout_Medic.Show()
        Me.Hide()

    End Sub

    ' Section Medecin
    Private Sub AddMed_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddMed.Click

        Ajout_Med.Show()
        Me.Hide()

    End Sub

    ' Bouton quitter
    Private Sub Quitter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Quitter.Click

        ' On quitte l'application
        Me.Close()

    End Sub

    Private Sub Accueil_Gen_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' connection
        connString = "DSN=ORA12;Uid=SLAM12;Pwd=Iroise29;"

        myConnection.ConnectionString = connString

        Try
            myConnection.Open()
            'MessageBox.Show("Connexion Oracle OK")
        Catch ex As Odbc.OdbcException
            MessageBox.Show(ex.Message)
        End Try

    End Sub
End Class
