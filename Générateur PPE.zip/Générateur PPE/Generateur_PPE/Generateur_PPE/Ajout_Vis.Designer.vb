﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Ajout_Vis
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Ajout_Vis))
        Me.AfficheTab = New System.Windows.Forms.DataGridView()
        Me.Scrollbar = New System.Windows.Forms.ComboBox()
        Me.RetourAccueil = New System.Windows.Forms.Button()
        Me.AjoutVis = New System.Windows.Forms.Button()
        Me.Nom_Vis = New System.Windows.Forms.Label()
        Me.Insert_Nom = New System.Windows.Forms.TextBox()
        Me.Prenom_Vis = New System.Windows.Forms.Label()
        Me.Mdp_vis = New System.Windows.Forms.Label()
        Me.Ville_Vis = New System.Windows.Forms.Label()
        Me.Insert_Prenom = New System.Windows.Forms.TextBox()
        Me.Insert_Adresse = New System.Windows.Forms.TextBox()
        Me.Insert_MDP = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.AfficheTab, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'AfficheTab
        '
        Me.AfficheTab.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.AfficheTab.Location = New System.Drawing.Point(101, 60)
        Me.AfficheTab.Name = "AfficheTab"
        Me.AfficheTab.Size = New System.Drawing.Size(321, 250)
        Me.AfficheTab.TabIndex = 2
        '
        'Scrollbar
        '
        Me.Scrollbar.FormattingEnabled = True
        Me.Scrollbar.Location = New System.Drawing.Point(101, 12)
        Me.Scrollbar.Name = "Scrollbar"
        Me.Scrollbar.Size = New System.Drawing.Size(321, 21)
        Me.Scrollbar.TabIndex = 3
        '
        'RetourAccueil
        '
        Me.RetourAccueil.BackColor = System.Drawing.Color.Red
        Me.RetourAccueil.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.RetourAccueil.Location = New System.Drawing.Point(359, 454)
        Me.RetourAccueil.Name = "RetourAccueil"
        Me.RetourAccueil.Size = New System.Drawing.Size(193, 35)
        Me.RetourAccueil.TabIndex = 4
        Me.RetourAccueil.Text = "Retourner à l'accueil"
        Me.RetourAccueil.UseVisualStyleBackColor = False
        '
        'AjoutVis
        '
        Me.AjoutVis.Location = New System.Drawing.Point(12, 454)
        Me.AjoutVis.Name = "AjoutVis"
        Me.AjoutVis.Size = New System.Drawing.Size(75, 23)
        Me.AjoutVis.TabIndex = 5
        Me.AjoutVis.Text = "Ajouter"
        Me.AjoutVis.UseVisualStyleBackColor = True
        '
        'Nom_Vis
        '
        Me.Nom_Vis.AutoSize = True
        Me.Nom_Vis.Location = New System.Drawing.Point(49, 390)
        Me.Nom_Vis.Name = "Nom_Vis"
        Me.Nom_Vis.Size = New System.Drawing.Size(38, 13)
        Me.Nom_Vis.TabIndex = 6
        Me.Nom_Vis.Text = "Nom : "
        '
        'Insert_Nom
        '
        Me.Insert_Nom.Location = New System.Drawing.Point(101, 390)
        Me.Insert_Nom.Name = "Insert_Nom"
        Me.Insert_Nom.Size = New System.Drawing.Size(134, 20)
        Me.Insert_Nom.TabIndex = 7
        '
        'Prenom_Vis
        '
        Me.Prenom_Vis.AutoSize = True
        Me.Prenom_Vis.Location = New System.Drawing.Point(38, 357)
        Me.Prenom_Vis.Name = "Prenom_Vis"
        Me.Prenom_Vis.Size = New System.Drawing.Size(49, 13)
        Me.Prenom_Vis.TabIndex = 8
        Me.Prenom_Vis.Text = "Prénom :"
        '
        'Mdp_vis
        '
        Me.Mdp_vis.AutoSize = True
        Me.Mdp_vis.Location = New System.Drawing.Point(250, 357)
        Me.Mdp_vis.Name = "Mdp_vis"
        Me.Mdp_vis.Size = New System.Drawing.Size(80, 13)
        Me.Mdp_vis.TabIndex = 9
        Me.Mdp_vis.Text = "Mot de passe : "
        '
        'Ville_Vis
        '
        Me.Ville_Vis.AutoSize = True
        Me.Ville_Vis.Location = New System.Drawing.Point(36, 423)
        Me.Ville_Vis.Name = "Ville_Vis"
        Me.Ville_Vis.Size = New System.Drawing.Size(51, 13)
        Me.Ville_Vis.TabIndex = 11
        Me.Ville_Vis.Text = "Adresse :"
        '
        'Insert_Prenom
        '
        Me.Insert_Prenom.Location = New System.Drawing.Point(101, 354)
        Me.Insert_Prenom.Name = "Insert_Prenom"
        Me.Insert_Prenom.Size = New System.Drawing.Size(134, 20)
        Me.Insert_Prenom.TabIndex = 12
        '
        'Insert_Adresse
        '
        Me.Insert_Adresse.Location = New System.Drawing.Point(101, 420)
        Me.Insert_Adresse.Name = "Insert_Adresse"
        Me.Insert_Adresse.Size = New System.Drawing.Size(134, 20)
        Me.Insert_Adresse.TabIndex = 14
        '
        'Insert_MDP
        '
        Me.Insert_MDP.Location = New System.Drawing.Point(336, 354)
        Me.Insert_MDP.Name = "Insert_MDP"
        Me.Insert_MDP.Size = New System.Drawing.Size(134, 20)
        Me.Insert_MDP.TabIndex = 15
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(432, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(120, 102)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 18
        Me.PictureBox1.TabStop = False
        '
        'Ajout_Vis
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(564, 501)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Insert_MDP)
        Me.Controls.Add(Me.Insert_Adresse)
        Me.Controls.Add(Me.Insert_Prenom)
        Me.Controls.Add(Me.Ville_Vis)
        Me.Controls.Add(Me.Mdp_vis)
        Me.Controls.Add(Me.Prenom_Vis)
        Me.Controls.Add(Me.Insert_Nom)
        Me.Controls.Add(Me.Nom_Vis)
        Me.Controls.Add(Me.AjoutVis)
        Me.Controls.Add(Me.RetourAccueil)
        Me.Controls.Add(Me.Scrollbar)
        Me.Controls.Add(Me.AfficheTab)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Ajout_Vis"
        Me.Text = "Ajout_Vis"
        CType(Me.AfficheTab, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents AfficheTab As System.Windows.Forms.DataGridView
    Friend WithEvents Scrollbar As System.Windows.Forms.ComboBox
    Friend WithEvents RetourAccueil As System.Windows.Forms.Button
    Friend WithEvents AjoutVis As System.Windows.Forms.Button
    Friend WithEvents Nom_Vis As System.Windows.Forms.Label
    Friend WithEvents Insert_Nom As System.Windows.Forms.TextBox
    Friend WithEvents Prenom_Vis As System.Windows.Forms.Label
    Friend WithEvents Mdp_vis As System.Windows.Forms.Label
    Friend WithEvents Ville_Vis As System.Windows.Forms.Label
    Friend WithEvents Insert_Prenom As System.Windows.Forms.TextBox
    Friend WithEvents Insert_Adresse As System.Windows.Forms.TextBox
    Friend WithEvents Insert_MDP As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
End Class
